import React from 'react';

const ErrorComponent = () => {
    return (
        <div style={{ textAlign: 'center', marginTop: '20px' }}>
                    <br /><br /><br /><br /><br /><br /><br />

            <h2>Access Denied</h2>
            <p>Please log in to access this page.</p>
        </div>
    );
};

export default ErrorComponent;
