import React from 'react'
import SimpleCarousel from './SimpleCarousel'

export const Dashboard = () => {
  return (
    <div>
        <SimpleCarousel />
      </div>
  )
}
