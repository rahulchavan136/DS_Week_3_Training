import React from 'react'

export const HomeLoan = () => {
  return (
    <strong>
        <br /><br /><br /><br /><br /><br /><br />
        Home Loan</strong>
  )
}
