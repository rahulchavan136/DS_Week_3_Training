import React, { useState } from 'react'
import { Button, Col, Container, Form, Row, Table } from 'react-bootstrap'


const LoanCalculator = () => {
    const loanTypes = [{
        name: 'Personal Loan',
        roi: 11
    }, {
        name: 'Home Loan',
        roi: 15
    }, {
        name: 'Car Loan',
        roi: 8.8
    }]
    const formFieldStyle = {
        display: 'flex', flexDirection: 'column', fontWeight: '600', alignItems: 'flex-start'
    }
    const [loanForm, setLoanForm] = useState({ loantype: '', amount: 0,year: 0 })
    const [calculatedEMI,setCalculatedEMI] = useState(0)

    const handleChange = (e) => {
        setLoanForm({ ...loanForm, [e.target.name]: e.target.value })
    }
    const handleClick = () => {
        const ROI = loanTypes.find((loan)=>loan.name === loanForm.loantype).roi
        const monthlyROI= ROI/12/100
        const principle = loanForm.amount
        const tenure = loanForm.year*12
        const EMI = (principle*monthlyROI*Math.pow((1+monthlyROI),tenure))/(Math.pow((1+monthlyROI),tenure)-1)
        setCalculatedEMI(EMI.toFixed(2))
    }
    return (
        <Container style={{ marginTop: '150px' }}>
            <h2>Loan Calculator</h2>
            <br/>
            <br/>
            <Row>
                <Col lg={5} sm={12} style={{border:'1px solid #c3c3c3',padding:'25px',borderRadius:'10px',margin:'0 15px'}}>
                <div><b>Fill the details to calculate your Loan and EMI</b></div>
                <br/>
                    <Form >
                        <Form.Group className="mb-3" controlId="loan" style={formFieldStyle}>
                            <Form.Select aria-label="Loan Type" name="loantype" onChange={(e) => handleChange(e)}>
                                <option>Enter Loan Type</option>
                                {
                                    loanTypes.map((loan, index) => { return <option value={loan.name} key={index}>{loan.name}</option> })
                                }

                            </Form.Select>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="lname" style={formFieldStyle}>
                            <Form.Label>Amount</Form.Label>
                            <Form.Control type="text" placeholder="Loan Amount" name="amount" onChange={(e) => handleChange(e)} />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="year" style={formFieldStyle}>
                            <Form.Label>Year</Form.Label>
                            <Form.Control type="text" placeholder="Year" maxLength={10} name="year" onChange={(e) => handleChange(e)} />
                        </Form.Group>
                        <Button onClick={handleClick}>Calculate</Button>
                    </Form>
                </Col>
                <Col lg={1} sm={12}></Col>
                <Col lg={5} sm={12} style={{border:'1px solid #c3c3c3',padding:'25px',borderRadius:'10px',margin:'0 15px'}}>
                    <div>
                       <b>Here's how your repayments might look</b> 
                    </div>
                    <br/>
                    <Table  striped bordered hover size="md">
                                <tbody>
                                    <tr>
                                        <td>Monthly Repayment</td>
                                        <td>Rs. {parseInt(calculatedEMI)}</td>
                                    </tr>
                                    <tr>
                                        <td>Interest Rate</td>
                                        <td>{loanForm.amount && calculatedEMI ? loanTypes.find((loan)=>loan.name === loanForm?.loantype).roi : 0}% p.a.</td>
                                    </tr>
                                    <tr>
                                        <td>Interest</td>
                                        <td>Rs. {loanForm.amount  && calculatedEMI ? (calculatedEMI*loanForm.year*12-parseFloat(loanForm.amount)).toFixed(2) : 0}</td>
                                    </tr>
                                    <tr>
                                        <td>Total Outflow</td>
                                        <td>Rs. {loanForm.amount && calculatedEMI ? (calculatedEMI*loanForm.year*12).toFixed(2) : 0}</td>
                                    </tr>
                                </tbody>
                    </Table>
                </Col>
            </Row>

        </Container>
    )
}

export default LoanCalculator