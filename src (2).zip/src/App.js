import React, { useState } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import MyNavbar from './Routes/MyNavbar';
import LoanPaymentSystem from './LoanPayment/LoanPaymentSystem';
import Footer from './LoanPayment/Footer';
 import {TwoWheelerLoan} from './LoanPayment/TwoWheelerLoan';
import Login from './LoanPayment/Login';
import {HomeLoan} from './LoanPayment/HomeLoan'

const App = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [username, setUsername] = useState('');

    const handleLogin = (formData) => {
         setIsLoggedIn(true);
        setUsername(formData.username);
    };

    const handleLogout = () => {
        // e.g., clear local storage, reset state
        setIsLoggedIn(false);
        setUsername('');
    };

    return (
        <div className='App'>
            <BrowserRouter>
                {isLoggedIn && <MyNavbar isLoggedIn={isLoggedIn} username={username} onLogout={handleLogout} />}
                <Routes>
                    <Route path='/' element={<Login onLogin={handleLogin} />} />
                    {isLoggedIn && <Route path='/personalloan' element={<LoanPaymentSystem />} />}
                    {isLoggedIn && <Route path='/homeloan' element={<HomeLoan />} />}
                    {isLoggedIn && <Route path='/twowheelerloan' element={<TwoWheelerLoan />} />}
                </Routes>
                {isLoggedIn && <Footer />}
            </BrowserRouter>
        </div>
    );
};

export default App;
