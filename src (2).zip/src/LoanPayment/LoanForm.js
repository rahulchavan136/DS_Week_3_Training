import React, { useState } from 'react';
import { Card, Button, Form, Row, Col } from 'react-bootstrap';

const LoanForm = ({ onAddLoan }) => {
    const [newLoanAmount, setNewLoanAmount] = useState('');
    const [newLoanInterestRate, setNewLoanInterestRate] = useState('');

    const handleAddLoan = () => {
        const newLoan = {
            amount: parseFloat(newLoanAmount),
            interestRate: parseFloat(newLoanInterestRate),
        };
        onAddLoan(newLoan);
        setNewLoanAmount('');
        setNewLoanInterestRate('');
    };

    return (
        <Card className="mt-4">
            <Card.Header>
                <Card.Title className="mb-0">Add New Loan</Card.Title>
            </Card.Header>
            <Card.Body>
                <Form>
                    <Row>
                        <Col md={6}>
                            <Form.Group controlId="newLoanAmount">
                                <Form.Label>Loan Amount</Form.Label>
                                <Form.Control
                                    type="number"
                                    value={newLoanAmount}
                                    onChange={(e) => setNewLoanAmount(e.target.value)}
                                    placeholder="Enter loan amount"
                                />
                            </Form.Group>
                        </Col>
                        <Col md={6}>
                            <Form.Group controlId="newLoanInterestRate">
                                <Form.Label>Interest Rate (%)</Form.Label>
                                <Form.Control
                                    type="number"
                                    value={newLoanInterestRate}
                                    onChange={(e) => setNewLoanInterestRate(e.target.value)}
                                    placeholder="Enter interest rate"
                                />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Button variant="success" onClick={handleAddLoan} className="mt-3">
                        Add Loan
                    </Button>
                </Form>
            </Card.Body>
        </Card>
    );
};

export default LoanForm;
