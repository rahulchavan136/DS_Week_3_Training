import React from 'react'

export const TwoWheelerLoan = () => {
  return (
    <strong>
        <br /><br /><br /><br /><br /><br /><br />
        Two Wheeler Loan</strong>
  )
}
