import React from 'react';
import './App.css';
 import 'bootstrap/dist/css/bootstrap.min.css';
import ProductsCard from './components/ProductsCard';
import ProductsTable from './components/ProductsTable';
 
 
function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <ProductsTable /> */}
         <ProductsCard />
      </header>
    </div>
  );
}

export default App;
