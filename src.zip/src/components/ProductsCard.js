import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import AddStudentForm from './AddStudentForm';

const ProductsCard = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
     const fetchStudents = async () => {
      try {
        const response = await axios.get('http://localhost:5000/students');
        setStudents(response.data);
      } catch (error) {
        console.error('Error fetching students:', error);
      }
    };

    fetchStudents();
  }, []);

  const handleStudentAdded = (newStudent) => {
    // Update students state to include the new student
    setStudents([...students, newStudent]);
  };

  return (
    <Container>
      {/* AddStudentForm component */}
      <AddStudentForm onStudentAdded={handleStudentAdded} />

       <Row>
        {students.map((student) => (
          <Col md={4} key={student.id} className="mb-4">
            <Card className="h-100">
              <Card.Body>
                <Card.Title>{student.name}</Card.Title>
                <Card.Text>
                  Grade: {student.grade} <br />
                  Maths: {student.marks.maths} <br />
                  Physics: {student.marks.physics} <br />
                  Chemistry: {student.marks.chemistry} <br />
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default ProductsCard;
